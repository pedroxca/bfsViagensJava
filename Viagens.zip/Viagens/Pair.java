package Viagens;

public class Pair {
  
}
