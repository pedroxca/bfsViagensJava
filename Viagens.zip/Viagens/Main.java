package Viagens;

import java.math.BigDecimal;

public class Main {
  public static void main(String[] args) {
    // Locais locais = new Locais();
    // Utils.printMatrix(locais.getMatrix());
    // System.out.println(locais.getLocais());
    // locais.printNeighbours();
    Travelmpl travel = new Travelmpl();
    System.out.println(travel.isReachable("POA", "GRU", 4));
  }
}
