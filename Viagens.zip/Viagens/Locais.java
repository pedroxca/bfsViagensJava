package Viagens;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

public class Locais {
  private String[] locaisExistentes = {
      "POA", "BSB", "GRU", "NAT",
      "SSA", "SDU", "VCP", "REC"
  };
  private int vertices = locaisExistentes.length;
  private Map<String, Map<String, Boolean>> locais = new LinkedHashMap<>();
  private int[][] matrix = new int[vertices][vertices];
  private List<ArrayList<String>> adjList = new ArrayList<>();

  public Locais() {
    for (String local : locaisExistentes) {
      locais.put(local, new HashMap<String, Boolean>());
      for (String localIn : locaisExistentes) {
        locais.get(local).put(localIn.toString(), Boolean.FALSE);
      }
    }
    locais.get("POA").put("BSB", true);

    locais.get("BSB").put("SSA", true);
    locais.get("BSB").put("NAT", true);
    locais.get("BSB").put("GRU", true);

    locais.get("SSA").put("REC", true);
    locais.get("SSA").put("NAT", true);

    locais.get("GRU").put("POA", true);
    locais.get("GRU").put("NAT", true);
    locais.get("GRU").put("REC", true);
    locais.get("GRU").put("BSB", true);

    locais.get("SDU").put("SSA", true);
    locais.get("VCP").put("SSA", true);

    int i = 0;
    int j = 0;
    for (var local : locais.entrySet()) {
      adjList.add(i, new ArrayList<>());
      ArrayList<String> tempArrayList = new ArrayList<>();
      for (var para : local.getValue().entrySet()) {
        if (para.getValue().equals(Boolean.TRUE)) {
          matrix[i][j] = 1;
          tempArrayList.add(para.getKey());
        }
        j++;
      }
      adjList.add(i, tempArrayList);
      i++;
      j = 0;
    }
    // System.out.println(adjList);
  }

  public int[][] getMatrix() {
    return matrix;
  }

  public Map<String, Map<String, Boolean>> getLocais() {
    return locais;
  }

  public void printNeighbours() {
    for (var place : locais.entrySet()) {
      for (var goesTo : place.getValue().entrySet()) {
        if (goesTo.getValue().equals(Boolean.TRUE)) {
          System.out.println(String.format("Place: %s points to %s", place.getKey(), goesTo.getKey()));
        }
      }
    }
  }

  public int getVertices() {
    return vertices;
  }

  public String[] getLocaisExistentes() {
    return locaisExistentes;
  }

  public int getIndexOfPlace(String place) {
    for (int i = 0; i < locaisExistentes.length; i++) {
      if (place.equals(locaisExistentes[i])) {
        return i;
      }
    }
    return -1;
  }
  public List<ArrayList<String>> getAdjList() {
    return adjList;
  }
}
