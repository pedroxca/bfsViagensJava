package Viagens;

public class Utils {
  static public void printMatrix(int[][] t) {
    for (int i = 0; i < t.length; i++) {
      for (int j = 0; j < t[i].length; j++) {
        System.out.print(t[i][j] + "  ");
      }
      System.out.println();
    }
  }
}