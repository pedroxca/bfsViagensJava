package Viagens;

public interface Travel {
  boolean isReachable(String from, String to, int numberConnections);
}
