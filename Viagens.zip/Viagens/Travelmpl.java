package Viagens;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.Queue;
import java.util.Set;
import java.util.Stack;

import javax.xml.stream.events.EndDocument;

public class Travelmpl implements Travel {
  private Locais locais = new Locais();

  @Override
  public boolean isReachable(String from, String to, int numberConnections) {
    List<Integer> doesItGoes = bfs(from, to);
    if (doesItGoes.get(0).equals(Integer.valueOf(-1))) {
      return false;
    }
    if (doesItGoes.get(1).compareTo(Integer.valueOf(numberConnections)) <= 0) {
      return true;
    }
    return false;
  }

  public List<Integer> bfs(String start, String end) {
    if (!locais.getLocais().containsKey(start) || !locais.getLocais().containsKey(end)) {
      return Arrays.asList(-1, -1);
    }
    if (start.equals(end)) {
      return Arrays.asList(0, 0);
    }
    String ss = start;
    Integer nOfCon = 0;

    Queue<String> queue = new LinkedList<>();
    boolean[] visited = new boolean[locais.getVertices()];
    queue.add(start);

    while (!queue.isEmpty()) {

      int root_index = locais.getIndexOfPlace(queue.peek());

      if (root_index != -1)
        visited[root_index] = true;

      start = queue.poll();
      System.out.print(start + " ");
      var currentPlaceAdjList = locais.getAdjList().get(locais.getIndexOfPlace(start));
      if (currentPlaceAdjList.size() != 0) {
        for (int i = 0; i < currentPlaceAdjList.size(); i++) {
          if (currentPlaceAdjList.get(i).equals(end)) {
            System.out.println(ss + " goes to " + end + " with " + nOfCon + " connections");
            return Arrays.asList(0, (nOfCon));
          }
        }
        nOfCon++;
      }
      Iterator<String> iterator = currentPlaceAdjList.listIterator();
      while (iterator.hasNext()) {
        int n = locais.getIndexOfPlace(iterator.next());
        // System.out.println(locais.getLocaisExistentes()[n]);
        if (!visited[n]) {
          visited[n] = true;
          queue.add(locais.getLocaisExistentes()[n]);
        }
      }
    }
    return Arrays.asList(-1, nOfCon);
  }

  // public boolean dfs(String start, String end) {
  //   if (!locais.getLocais().containsKey(start)) {
  //     return false;
  //   }

  //   Stack<String> stack = new Stack<>();
  //   boolean[] visited = new boolean[locais.getVertices()];
  //   stack.push(start);

  //   while (!stack.empty()) {

  //     int root_index = locais.getIndexOfPlace(stack.peek());

  //     if (root_index != -1)
  //       visited[root_index] = true;

  //     start = stack.pop();

  //     System.out.print(start + " ");
  //     System.out.println();

  //     var currentPlaceAdjList = locais.getAdjList().get(locais.getIndexOfPlace(start));
  //     System.out.println(currentPlaceAdjList);
  //     ListIterator<String> i = currentPlaceAdjList.listIterator();
  //     while (i.hasNext()) {
  //       int n = locais.getIndexOfPlace(i.next());
  //       if (!visited[n]) {
  //         if (i.next().equals(end))
  //           return true;

  //         visited[n] = true;
  //         stack.add(locais.getLocaisExistentes()[n]);
  //       }
  //     }
  //   }
  //   return false;
  // }

}
